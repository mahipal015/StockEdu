//
//  StockListViewModel.swift
//  StockEdu
//
//  Created by Mahipal Kummari on 27/01/21.
//

import Combine

final class StockListViewModel : ObservableObject {
    @Published var stockRepository = StockRepository()
    @Published var stockViewModels: [StockViewModel] = []
    
    private var cancellables: Set<AnyCancellable> = []
    
    init() {
        stockRepository.$stocks.map{stocks in
            stocks.map(StockViewModel.init)}
         .assign(to: \.stockViewModels,on: self)
         .store(in: &cancellables)
    }
    
    func add(_ stock:Stock) {
        stockRepository.add(stock)
    }
    
    func remove(_ stock:Stock) {
        stockRepository.remove(stock)
    }
    
    func update(_ stock:Stock) {
        stockRepository.update(stock)
    }
}
