//
//  StockViewModel.swift
//  StockEdu
//
//  Created by Mahipal Kummari on 27/01/21.
//

import Combine
final class StockViewModel : ObservableObject,Identifiable {
    private let stockRepository = StockRepository()
    @Published var stock: Stock
    
    var id = ""
    
    private var cancellables: Set<AnyCancellable> = []
    
    init(stock: Stock) {
        self.stock = stock
            $stock.compactMap{$0.id }
            .assign(to: \.id,on: self)
            .store(in: &cancellables)
    }
    
    func add(_ stock:Stock) {
        stockRepository.add(stock)
    }
}

