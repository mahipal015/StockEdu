//
//  StockEduApp.swift
//  StockEdu
//
//  Created by Mahipal Kummari on 23/01/21.
//

import SwiftUI
import Firebase

@main
struct StockEduApp: App {
   // @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    init() {
        print("Firebase Setting")
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}

//class AppDelegate:NSObject,UIApplicationDelegate{
//    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
//        print("Firebase Setiing")
//        FirebaseApp.configure()
//        return true
//    }
//
//
//}
