//
//  StockRepository.swift
//  StockEdu
//
//  Created by Mahipal Kummari on 27/01/21.
//

import FirebaseFirestore
import FirebaseFirestoreSwift
import Combine

final class StockRepository: ObservableObject {
    private let path = "stocks"
    private let store = Firestore.firestore()
    @Published var stocks :[Stock] = []
    
    init() {
        get()
    }
    
    func get(){
        store.collection(path).addSnapshotListener { (snapshot, error) in
            if let error = error {
                print(error.localizedDescription)
                return
            }
            self.stocks = snapshot?.documents.compactMap{
                try? $0.data(as: Stock.self)
                
            } ?? []
        }
        
    }
    
    func add(_ stock: Stock) {
        do {
            _ = try store.collection(path).addDocument(from: stock)
        }catch {
            fatalError("Adding stock failed")
        }
    }
    
    func remove(_ stock: Stock) {
        guard let documentId = stock.id else {return}
        store.collection(path).document(documentId).delete{ error in
            if let error = error {
                print("Unable to delete the stock \(error.localizedDescription)")
            }
            
        }
        
    }
    
    func update(_ stock: Stock){
        guard let documentId = stock.id else {return}
        do {
            try store.collection(path).document(documentId).setData(from: stock)
        }catch {
            fatalError("Updating stock failed")
        }
    }
}
