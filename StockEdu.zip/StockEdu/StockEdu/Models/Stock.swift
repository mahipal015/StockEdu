//
//  Stock.swift
//  StockEdu
//
//  Created by Mahipal Kummari on 27/01/21.
//

import FirebaseFirestoreSwift

struct Stock:Identifiable,Codable {
    
    @DocumentID var id: String?
    var stockName: String
    var currentPrice: String
    
    var entryPrice: String
    var stockCount: String
    
    var pt1: String
    var pt2: String
    
    var stockStatus: String
    
}
