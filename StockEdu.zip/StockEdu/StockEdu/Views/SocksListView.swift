//
//  SocksListView.swift
//  StockEdu
//
//  Created by Mahipal Kummari on 27/01/21.
//

import SwiftUI

struct SocksListView: View {
    @ObservedObject var stockListViewModel : StockListViewModel
    @State private var showForm = false
    
    var body: some View {
        
        NavigationView{
        VStack{
            List{
                ForEach(stockListViewModel.stockViewModels){ stockVM in
                StockView(stockViewMoel: stockVM)
                }.onDelete(perform: delete)
            }
            .listStyle(InsetListStyle())
            .navigationTitle("Stocks")
            .foregroundColor(.purple)
            
            Button(action: {
                showForm = true
            }){
            Circle()
                .fill(Color("top"))
                .frame(height:60)
                .overlay(Image(systemName: "plus"))
                .foregroundColor(.white)
            }.sheet(isPresented: $showForm){
                StockFormView{(stock) in
                    stockListViewModel.add(stock)
                    showForm = false
                }
            }
            
        }
        }
        
    }
    
    private func delete(at offsets:IndexSet){
        offsets.map{ stockListViewModel.stockViewModels[$0].stock
        }.forEach(stockListViewModel.remove)
    }
}

struct SocksListView_Previews: PreviewProvider {
    static var previews: some View {
        SocksListView(stockListViewModel: StockListViewModel())
    }
}
