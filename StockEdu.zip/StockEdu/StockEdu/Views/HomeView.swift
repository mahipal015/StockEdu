//
//  ContentView.swift
//  StockEdu
//
//  Created by Mahipal Kummari on 23/01/21.
//

import SwiftUI

struct HomeView: View {
    @AppStorage("log_Status") var status = false
    @StateObject var model = LoginViewModel()
    
    var body: some View {
        
        ZStack{
            
            if status{
                VStack(alignment: .trailing){
                    Button(action: model.logOut, label: {
                        Text("LogOut")
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                            .fontWeight(.bold)

                    }).padding(.trailing,20)
                    
                    SocksListView(stockListViewModel: StockListViewModel())
                    
                }
            }
            else{
                
                LoginView(model: model)
            }
        }
        .background(LinearGradient(gradient: .init(colors: [Color("top"),Color("bottom")]), startPoint: .top, endPoint: .bottom).ignoresSafeArea(.all, edges: .all))
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
