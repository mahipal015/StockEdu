//
//  StockFormView.swift
//  StockEdu
//
//  Created by Mahipal Kummari on 27/01/21.
//

import SwiftUI

struct StockFormView: View {
    @State private var stockName:String = ""
    @State private var currentPrice:String = ""
    @State private var entryPrice:String = ""
    @State private var stockStatus: String = ""
    @State private var stockCount: String = ""
    @State private var pt1: String = ""
    @State private var pt2: String = ""
    
    var didAddStock:(_ stock:Stock) -> Void
    
    var body: some View{
        NavigationView{
            VStack{
                Form{
                    TextField("Stock Name",text:$stockName)
                    TextField("Current Price",text:$currentPrice)
                    TextField("EntryPrice",text:$entryPrice)
                    TextField("Status",text:$stockStatus)
                    TextField("Stock Count",text:$stockCount)
                    TextField("PT1",text:$pt1)
                    TextField("PT2",text:$pt2)
                    
                }
                Button("Create Stock"){
                    let stock = Stock(stockName: stockName, currentPrice: currentPrice, entryPrice: entryPrice, stockCount: stockCount, pt1: pt1, pt2: pt2, stockStatus: stockStatus)
                    didAddStock(stock)
                    
                }.disabled(stockName.isEmpty || currentPrice.isEmpty || entryPrice.isEmpty || stockStatus.isEmpty || stockCount.isEmpty || pt1.isEmpty || pt2.isEmpty)
                .padding()
            }.navigationTitle("New Stock")
        }
    }
    
    
}
