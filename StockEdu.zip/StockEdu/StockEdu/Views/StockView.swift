//
//  StockView.swift
//  StockEdu
//
//  Created by Mahipal Kummari on 27/01/21.
//

import SwiftUI

struct StockView: View {
    var stockViewMoel : StockViewModel
    var body: some View {
        
        RoundedRectangle(cornerRadius: 10.0)
            .fill(Color("bottom"))
            .frame(height:100)
            .overlay(
                VStack(){
                    HStack{
                        HStack{
                        Text("Name:").foregroundColor(.white)
                        Text(stockViewMoel.stock.stockName).foregroundColor(.white)
                        }
                        Spacer(minLength: 10)
                        HStack{
                        Text("Price:").foregroundColor(.white)
                        Text(stockViewMoel.stock.currentPrice).foregroundColor(.white)
                        }
                        
                    }
                    HStack(){
                        HStack{
                        Text("Entry Price:").foregroundColor(.white)
                        Text(stockViewMoel.stock.entryPrice).foregroundColor(.white)
                        }
                        Spacer(minLength: 10)
                        HStack{
                        Text("Stock Count:").foregroundColor(.white)
                        Text(stockViewMoel.stock.stockCount).foregroundColor(.white)
                        }
                    }
                    HStack{
                        HStack{
                        Text("Profit-1:").foregroundColor(.white)
                        Text(stockViewMoel.stock.pt1).foregroundColor(.white)
                        }
                        Spacer(minLength: 10)
                        HStack{
                        Text("Profit-2:").foregroundColor(.white)
                        Text(stockViewMoel.stock.pt2).foregroundColor(.white)
                        }
                    }
                    HStack{
                        Text("Status:").foregroundColor(.white)
                        Text(stockViewMoel.stock.stockStatus).foregroundColor(.white)
                    }
                }.padding()
            )
        
    }
}

//struct StockView_Previews: PreviewProvider {
//    static var previews: some View {
//        StockView(stockViewMoel: StockViewModel())
//    }
//}
